make all 
	for minimal output
make print 
	for a view of all matrices


indent *.cpp -nbad -nbap -npsl -br -brf

