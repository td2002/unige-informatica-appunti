/*
Mafodda Edoardo 5302507
Toscano Mattia  5288636
Trioli Davide   5316731

functions used throughout all the different source codes of main exercises

*/

#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

void sum_col (float *b1, float *deltab1, int m) {
  for (int i = 0; i < m; ++i)
    b1[i] = b1[i] + deltab1[i];
}

float *delta_construct (float val, int r) {
  float *res = new float[r];
  for (int i = 0; i < r; ++i) {
    res[i] = 0.01 * val;
    if (i % 2 == 0)
      res[i] = -res[i];
  }

  return res;
}

float *back_substitution (float **matrix, int r, int c) {
  float *x = new float[r];
  float sum = 0.0;
  for (int i = r - 1; i >= 0; --i) {
    sum = 0.0;
    for (int s = c - 1; s > i; --s) {
      sum += (matrix[i][s] * x[s]);
    }
    //col finale - sum diviso coeff
    x[i] = ((matrix[i][c - 1] - sum) / matrix[i][i]);
  }
  return x;
}

float *matrix_vector_prod (float **matrix, float v[], int m, int n) {
  float *prod_vec = new float[m];
  float sum;
  for (int i = 0; i < m; i++) {
    sum = 0;
    for (int j = 0; j < n; j++)
      sum += matrix[i][j] * v[j];

    prod_vec[i] = sum;
  }

  return prod_vec;
}

float row_sum (float *m, int n) {

  float sum = 0;
  for (int i = 0; i < n; ++i)
    sum += fabs (m[i]);
  return sum;
}

float inf_norm (float **m, int r, int c) {
  float max;
  max = m[0][0];
  float temp;
  for (int i = 0; i < r; ++i) {
    temp = row_sum (m[i], c);
    if (temp > max)
      max = temp;
  }
  return max;
}

float array_inf_norm (float *a, int r) {
//this function is used to better handle matrices where one dim is 1, i.e. arrays
  float max;
  max = a[0];
  float temp;
  for (int i = 0; i < r; ++i) {
    temp = fabs (a[i]);
    if (temp > max)
      max = temp;
  }
  return max;
}

long unsigned int factorial (int n) {
//long unsigned int is used to handle big numbers of the factorial
  if (n == 0) {
    return 1;
  }
  else {
    return (n * factorial (n - 1));
  }
}

long unsigned int pascal (int r, int c) {
  long unsigned int res =
    (factorial (r + c - 2)) / (factorial (c - 1) * factorial (r - 1));
  return res;
}

void print_matrix (float **m, int r, int c) {

  for (int i = 0; i < r; ++i) {
    for (int j = 0; j < c; ++j) {
      //cout << "[" << m[i][j] << "]\t";
      //printf is used to better handling of decimals with %g
      printf ("[%g]\t", m[i][j]);
    }
    cout << endl;
  }
}
void print_separator (string s) {
  int n = 32;
  cout << endl;
  if (s == "") {
    for (int i = 0; i <= n; ++i)
      cout << " -";
    cout << endl << endl;;
    return;
  }
  for (int i = 0; i < 2; ++i)
    cout << " -";
  cout << " " << s;
  int p = s.length () / 2;
  if ((p * 2) == s.length ()) {
    cout << " ";
  }
  for (int i = 0; i < (n - p - 2); ++i)
    cout << " -";
  cout << endl << endl;
  return;
}

void row_elim (float *cur_row, float *pv_row, int l, int pv_pos) {
  double cur_h = cur_row[pv_pos];
  double pivot = pv_row[pv_pos];
  for (int i = 0; i < l; ++i) {
    cur_row[i] = cur_row[i] - ((cur_h / pivot) * pv_row[i]);
  }
}

void gauss_elim (float **m, int r, int c) {
  float max = m[0][0];
  int i_max = -1;
  float arr[c];
  for (int k = 0; k < r; ++k) {
    //swap with max
    max = m[k][k];
    i_max = k;
    for (int w = k; w < r; ++w) {	//find max
      if (m[w][k] > max) {
	max = m[w][k];
	i_max = w;
      }
    }

    if (k != i_max) {		//swap if necessary
      for (int h = 0; h < c; ++h) {
	arr[h] = m[k][h];
      }
      for (int h = 0; h < c; ++h) {
	m[k][h] = m[i_max][h];
      }
      for (int h = 0; h < c; ++h) {
	m[i_max][h] = arr[h];
      }
    }

    for (int j = k + 1; j < r; ++j) {
      //rj = rj - (ajk/akk)rk
      row_elim (m[j], m[k], c, k);
    }
  }
}
