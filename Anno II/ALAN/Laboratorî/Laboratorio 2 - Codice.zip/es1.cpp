/*
Mafodda Edoardo 5302507
Toscano Mattia  5288636
Trioli Davide   5316731

*/

#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>

#include "./functions.cpp"

using namespace std;

int main () {

  print_separator ("ESERCIZIO 1");

  int n[4];
  int m[4];

  m[0] = 4;
  n[0] = m[0];
  float matrix_temp1[4][4] = {
    3.0, 1.0, -1.0, 0.0,
    0.0, 7.0, -3.0, 0.0,
    0.0, -3.0, 9.0, -2.0,
    0.0, 0.0, 4.0, -10.0
  };

  float **matrix1 = new float *[m[0]];
  for (int i = 0; i < n[0]; ++i)
    matrix1[i] = new float[n[0]];

  for (int i = 0; i < m[0]; i++) {
    for (int j = 0; j < m[0]; j++)
      matrix1[i][j] = matrix_temp1[i][j];
  }

#ifdef PRINT
  print_matrix (matrix1, m[0], n[0]);
#endif
  cout << "Norma infinito matrice 1: " << inf_norm (matrix1, m[0],
						    n[0]) << '\n';

  print_separator ("");

  //---------------------------------
  //------------- second matrix next

  m[1] = 4;
  n[1] = m[0];
  float matrix_temp2[4][4] = {
    2, 4, -2, 0,
    1, 3, 0, 1,
    3, -1, 1, 2,
    0, -1, 2, 1
  };

  float **matrix2 = new float *[m[1]];
  for (int i = 0; i < n[0]; ++i)
    matrix2[i] = new float[n[1]];

  for (int i = 0; i < m[1]; i++) {
    for (int j = 0; j < n[1]; j++)
      matrix2[i][j] = matrix_temp2[i][j];
  }
#ifdef PRINT
  print_matrix (matrix2, m[1], n[1]);
#endif
  cout << "Norma infinito matrice 2: " << inf_norm (matrix2, m[1],
						    n[1]) << '\n';

  print_separator ("");

  m[2] = 10;
  n[2] = m[2];

  float **matrix3 = new float *[m[2]];
  for (int i = 0; i < n[2]; ++i)
    matrix3[i] = new float[n[2]];

  for (int i = 0; i < m[2]; i++) {
    for (int j = 0; j < n[2]; j++) {
      matrix3[i][j] = pascal (i + 1, j + 1);
    }
  }
#ifdef PRINT
  print_matrix (matrix3, m[2], n[2]);
#endif
  cout << "Norma infinito matrice 3: " << inf_norm (matrix3, m[2],
						    n[2]) << '\n';

  print_separator ("");


  m[3] = 10 * (3 + 1) + 1;
  n[3] = m[3];

  float **matrix4 = new float *[m[3]];
  for (int i = 0; i < n[3]; ++i)
    matrix4[i] = new float[n[3]];

  for (int i = 0; i < m[3]; i++) {
    for (int j = 0; j < n[3]; j++) {
      matrix4[i][j] = (i == j ? 2 : (abs (i - j) == 1 ? -1 : 0));
    }
  }
#ifdef PRINT
  print_matrix (matrix4, m[3], n[3]);
#endif
  cout << "Norma infinito matrice 4: " << inf_norm (matrix4, m[3],
						    n[3]) << '\n';

  print_separator ("FINE ESERCIZIO 1");

  return 0;

}
