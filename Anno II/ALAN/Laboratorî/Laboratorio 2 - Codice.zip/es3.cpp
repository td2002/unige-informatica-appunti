/*
Mafodda Edoardo 5302507
Toscano Mattia  5288636
Trioli Davide   5316731

d0 = 1
d1 = 3
n = 10(3+1)+1 = 41
*/

#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>

#include "./functions.cpp"

using namespace std;


int main () {

  print_separator ("ESERCIZIO 3");

  int n[4];
  int m[4];


//----1° matrice -------------------------------
  n[0] = 4;
  m[0] = n[0];

  float *v1 = new float[m[0]];
  for (int i = 0; i < m[0]; ++i)
    v1[i] = 1;


  float matrix_temp1[4][4] = {
    3.0, 1.0, -1.0, 0.0,
    0.0, 7.0, -3.0, 0.0,
    0.0, -3.0, 9.0, -2.0,
    0.0, 0.0, 4.0, -10.0
  };
  float **matrix1 = new float *[m[0]];
  for (int i = 0; i < n[0]; ++i)
    matrix1[i] = new float[n[0]];
  for (int i = 0; i < m[0]; i++) {
    for (int j = 0; j < n[0]; j++) {
      matrix1[i][j] = matrix_temp1[i][j];
    }
  }

  float *b1 = new float[m[0]];
  b1 = matrix_vector_prod (matrix1, v1, m[0], n[0]);
  float *deltab1 = new float[m[0]];
  deltab1 = delta_construct (array_inf_norm (b1, m[0]), m[0]);
  sum_col (b1, deltab1, m[0]);
  print_separator ("Colonna termini noti matrice 1 (con errore)");
  print_matrix (&b1, 1, m[0]);

  //---costruzione matrice A|B (con la 1°)
  float **matrix1b = new float *[m[0]];
  for (int i = 0; i < n[0] + 1; ++i)
    matrix1b[i] = new float[n[0] + 1];
  for (int i = 0; i < m[0]; i++) {
    for (int j = 0; j < n[0] + 1; j++) {
      if (j < n[0])
	matrix1b[i][j] = matrix1[i][j];
      else
	matrix1b[i][j] = b1[i];
    }
  }
#ifdef PRINT
  print_separator ("Matrice 1 (A|b\u0303)");
  print_matrix (matrix1b, m[0], n[0] + 1);

  print_separator ("Matrice 1 (A|b\u0303) dopo riduzione di Gauss");
#endif
  gauss_elim (matrix1b, m[0], n[0] + 1);
#ifdef PRINT
  print_matrix (matrix1b, m[0], n[0] + 1);
#endif

  print_separator ("Soluzione sistema lineare matrice 1 (A|b\u0303)");
  float *x1 = new float[m[0]];

  x1 = back_substitution (matrix1b, m[0], n[0] + 1);
  print_matrix (&x1, 1, m[0]);

//----------------------------------------------
  print_separator ("");
//----2° matrice -------------------------------
  n[1] = 4;
  m[1] = n[1];
  float *v2 = new float[m[1]];
  for (int i = 0; i < m[1]; ++i)
    v2[i] = 1;
  float matrix_temp2[4][4] = {
    2, 4, -2, 0,
    1, 3, 0, 1,
    3, -1, 1, 2,
    0, -1, 2, 1
  };
  float **matrix2 = new float *[m[1]];
  for (int i = 0; i < n[1]; ++i)
    matrix2[i] = new float[n[1]];
  for (int i = 0; i < m[1]; i++) {
    for (int j = 0; j < n[1]; j++) {
      matrix2[i][j] = matrix_temp2[i][j];
    }
  }

  float *b2 = new float[m[1]];
  b2 = matrix_vector_prod (matrix2, v2, m[1], n[1]);
  float *deltab2 = new float[m[1]];
  deltab2 = delta_construct (array_inf_norm (b2, m[1]), m[1]);
  sum_col (b2, deltab2, m[1]);
  print_separator ("Colonna termini noti matrice 2 (con errore)");
  print_matrix (&b2, 1, m[1]);

  //---costruzione matrice A|B (con la 2°)
  float **matrix2b = new float *[m[1]];
  for (int i = 0; i < n[1] + 1; ++i)
    matrix2b[i] = new float[n[1] + 1];
  for (int i = 0; i < m[1]; i++) {
    for (int j = 0; j < n[1] + 1; j++) {
      if (j < n[1])
	matrix2b[i][j] = matrix2[i][j];
      else
	matrix2b[i][j] = b2[i];
    }
  }

#ifdef PRINT
  print_separator ("Matrice 2 (A|b\u0303)");
  print_matrix (matrix2b, m[1], n[1] + 1);

  print_separator ("Matrice 2 (A|b\u0303) dopo riduzione di Gauss");
#endif
  gauss_elim (matrix2b, m[1], n[1] + 1);
#ifdef PRINT
  print_matrix (matrix2b, m[1], n[1] + 1);
#endif

  print_separator ("Soluzione sistema lineare matrice 2 (A|b\u0303)");
  float *x2 = new float[m[1]];
  x2 = back_substitution (matrix2b, m[1], n[1] + 1);
  print_matrix (&x2, 1, m[1]);
//----------------------------------------------
  print_separator ("");
//----3° matrice -------------------------------
  n[2] = 10;
  m[2] = n[2];
  float *v3 = new float[m[2]];
  for (int i = 0; i < m[2]; ++i)
    v3[i] = 1;

  float **matrix3 = new float *[m[2]];
  for (int i = 0; i < n[2]; ++i)
    matrix3[i] = new float[n[2]];
  for (int i = 0; i < m[2]; i++) {
    for (int j = 0; j < n[2]; j++) {
      matrix3[i][j] = pascal (i + 1, j + 1);
    }
  }
  float *b3 = new float[m[2]];
  b3 = matrix_vector_prod (matrix3, v3, m[2], n[2]);
  float *deltab3 = new float[m[2]];
  deltab3 = delta_construct (array_inf_norm (b3, m[2]), m[2]);
  sum_col (b3, deltab3, m[2]);
  print_separator ("Colonna termini noti matrice 3 (con errore)");
  print_matrix (&b3, 1, m[2]);

  //---costruzione matrice A|B (con la 3°)
  float **matrix3b = new float *[m[2]];
  for (int i = 0; i < n[2] + 1; ++i)
    matrix3b[i] = new float[n[2] + 1];
  for (int i = 0; i < m[2]; i++) {
    for (int j = 0; j < n[2] + 1; j++) {
      if (j < n[2])
	matrix3b[i][j] = matrix3[i][j];
      else
	matrix3b[i][j] = b3[i];
    }
  }
#ifdef PRINT
  print_separator ("Matrice 3 (A|b\u0303)");
  print_matrix (matrix3b, m[2], n[2] + 1);

  print_separator ("Matrice 3 (A|b\u0303) dopo riduzione di Gauss");
#endif
  gauss_elim (matrix3b, m[2], n[2] + 1);
#ifdef PRINT
  print_matrix (matrix3b, m[2], n[2] + 1);
#endif

  print_separator ("Soluzione sistema lineare matrice 3 (A|b\u0303)");
  float *x3 = new float[m[2]];
  x3 = back_substitution (matrix3b, m[2], n[2] + 1);
  print_matrix (&x3, 1, m[2]);
//----------------------------------------------
  print_separator ("");
//----4° matrice -------------------------------
  //n[3]= 10*(3+1)+1;
  n[3] = 41;
  m[3] = n[3];
  float *v4 = new float[m[3]];
  for (int i = 0; i < m[3]; ++i)
    v4[i] = 1;

  float **matrix4 = new float *[m[3]];
  for (int i = 0; i < n[3]; ++i)
    matrix4[i] = new float[n[3]];
  for (int i = 0; i < m[3]; i++) {
    for (int j = 0; j < n[3]; j++) {
      matrix4[i][j] = (i == j ? 2 : (abs (i - j) == 1 ? -1 : 0));
    }
  }
  float *b4 = new float[m[3]];
  b4 = matrix_vector_prod (matrix4, v4, m[3], n[3]);
  float *deltab4 = new float[m[3]];
  deltab4 = delta_construct (array_inf_norm (b4, m[3]), m[3]);
  sum_col (b4, deltab4, m[3]);
  print_separator ("Colonna termini noti matrice 4 (con errore)");
  print_matrix (&b4, 1, m[3]);

  //---costruzione matrice A|B (con la 4°)
  float **matrix4b = new float *[m[3]];
  for (int i = 0; i < n[3] + 1; ++i)
    matrix4b[i] = new float[n[3] + 1];
  for (int i = 0; i < m[3]; i++) {
    for (int j = 0; j < n[3] + 1; j++) {
      if (j < n[3])
	matrix4b[i][j] = matrix4[i][j];
      else
	matrix4b[i][j] = b4[i];
    }
  }

#ifdef PRINT
  print_separator ("Matrice 4 (A|b\u0303)");
  print_matrix (matrix4b, m[3], n[3] + 1);

  print_separator ("Matrice 4 (A|b\u0303) dopo riduzione di Gauss");
#endif
  gauss_elim (matrix4b, m[3], n[3] + 1);
#ifdef PRINT
  print_matrix (matrix4b, m[3], n[3] + 1);
#endif

  print_separator ("Soluzione sistema lineare matrice 4 (A|b\u0303)");
  float *x4 = new float[m[3]];
  x4 = back_substitution (matrix4b, m[3], n[3] + 1);
  print_matrix (&x4, 1, m[3]);
//----------------------------------------------

  print_separator ("FINE ESERCIZIO 3");

  return 0;

}
