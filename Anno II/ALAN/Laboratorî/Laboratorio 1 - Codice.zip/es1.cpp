/*
Mafodda Edoardo 5302507
Toscano Mattia  5288636
Trioli Davide   5316731


Dati:
d0 = 7
d1 = 0
a = (d0 + 1)·10^i
i = 0,1,...,6 (cicla)
b = (d1 + 1)·10^20
c = −b

utilizzando double:
(a+b)+c
a+(b+c)

il risultato dovrebbe essere =a poiché b=-c
nei primi 4 casi, ossia dove 0<=i<=3, dove a è molto piccola rispetto a b e c, viene quasi trascurata (assorbita)
da i valori enormi di b e c, solo nei casi in cui viene eseguita per prima la somma tra a e b.
Nei casi in cui per prima viene eseguita la cancellazione (b+c) questo fenomeno non sussiste.
Nei successivi 3 casi, dove a aumenta sempre di più avvicinandosi ai valori assunti da b e c, quando la somma
a+b viene eseguita per prima questa non "assorbe" il valore di a ma ne risulta comunque un valore leggermente errato.
Questo errore diminuisce all'aumentare di a (-> b).
*/

#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

int main () {
  double d0 = 7;
  double d1 = 0;

  double a;
  double b = (d1 + 1) * pow (10, 20);
  double c = -b;
  for (int i = 0; i <= 6; ++i) {
    a = (d0 + 1) * pow (10, i);
    cout << " - - - Risultato per i = " << i << " - - -\n";
    cout << "a = " << a << "; b = " << b << "; c = " << c << "\n";
    cout << "(a+b)+c : " << (a + b) + c << "\n";
    cout << "a+(b+c) : " << a + (b + c) << "\n";
    cout << "errore relativo: " << (((a + b) + c) -
				    (a + (b + c))) / a << "\n";
  }
}
