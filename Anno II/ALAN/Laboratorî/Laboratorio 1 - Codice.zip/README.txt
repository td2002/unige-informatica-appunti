from command line type 
make
and press Enter

Run the .out files

