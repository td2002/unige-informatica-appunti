/*
Mafodda Edoardo 5302507
Toscano Mattia  5288636
Trioli Davide   5316731

*/

#include <cmath>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

int main () {
  float a = 2;
  float sum = a;
  int i = -1;
  for (i = -1;; --i) {
    sum = 1 + (pow (a, i));
    cout << "valore : " << i << " : " << sum << "\n";
    if (sum == 1)
      break;
  }
  cout << " ########## eps (float) = 2^(" << i+1 << ") = " << pow (2, i+1) << endl;

  double a_d = 2;
  double sum_d = a_d;
  i = -1;
  for (i = -1;; --i) {
    sum_d = 1 + (pow (a_d, i));
    cout << "valore : " << i << " : " << sum_d << "\n";
    if (sum_d == 1)
      break;
  }
  cout << " ########## eps (double) = 2^(" << i+1 << ") = " << pow (2, i+1) << endl;
}
