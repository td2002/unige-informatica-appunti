/*
Mafodda Edoardo 5302507
Toscano Mattia  5288636
Trioli Davide   5316731


Dati:
f(x)=e^x
fN(x)=sum(n=0,N)(x^n/n!)
parte 1:
x = 0.5, 30; N = 3, 10, 50, 100, 150
*/

#include <math.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
using namespace std;

double factorial (int n) {
  if (n == 0) {
    return 1;
  }
  else {
    return (n * factorial (n - 1));
  }
}

int main () {
  double x[2] = { 0.5, 30 }, N[5] = { 3, 10, 50, 100, 150 };

  cout << "## ALGORITMO 1 ##\n\n";

  double sum;
  for (int i = 0; i <= 1; ++i) {
    cout << ":: Funzione corretta e^" << x[i] << ": " << exp (x[i]) << "\n";
    for (int j = 0; j <= 4; ++j) {
      for (int n = 0; n <= N[j]; ++n) {
	sum += (pow (x[i], n)) / (factorial (n));
      }
      cout << "Per x = " << x[i] << " e N = " << N[j] <<
	" la funzione viene approssimata a " << sum << "\n";
      cout << "Errore assoluto: " << (sum - exp (x[i])) << "\n";
      cout << "Errore relativo: " << (sum -
				      exp (x[i])) / (exp (x[i])) << "\n\n";
      sum = 0;
    }
  }

  for (int i = 0; i <= 1; ++i) {
    cout << ":: Funzione corretta e^" << -x[i] << ": " << exp (-x[i]) << "\n";
    for (int j = 0; j <= 4; ++j) {
      for (int n = 0; n <= N[j]; ++n) {
	sum += (pow (-x[i], n)) / (factorial (n));
      }
      cout << "Per x = " << -x[i] << " e N = " << N[j] <<
	" la funzione viene approssimata a " << sum << "\n";
      cout << "Errore assoluto: " << (sum - exp (-x[i])) << "\n";
      cout << "Errore relativo: " << (sum - exp (-x[i])) / (exp (-x[i])) << "\n\n";
      sum = 0;
    }
  }

  cout << "## ALGORITMO 2 ##\n\n";

  for (int i = 0; i <= 1; ++i) {
    cout << ":: Funzione corretta e^" << -x[i] << ": " << exp (-x[i]) << "\n";
    for (int j = 0; j <= 4; ++j) {
      for (int n = 0; n <= N[j]; ++n) {
	sum += (pow (x[i], n)) / (factorial (n));
      }
      double approx = 1.0 / sum;
      cout << "Per x = " << -x[i] << " e N = " << N[j] <<
	" la funzione viene approssimata a " << approx << "\n";
      cout << "Errore assoluto: " << (approx - exp (-x[i])) << "\n";
      cout << "Errore relativo: " << (approx - exp (-x[i])) / (exp (-x[i])) << "\n\n";
      sum = 0;
    }
  }
}
